package com.jjmae.UDirtyRat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UDirtyRatApplication {

	public static void main(String[] args) {
		SpringApplication.run(UDirtyRatApplication.class, args);
	}
}
